# Equity Connection pages: Webflow paste kit

Tomos wrote these two pages himself and asked for them as real landing pages we can use. The copy is his, unchanged. This kit puts each page into Webflow the same way the HVAC, electrical and fleet pages went in: four paste blocks per page, one block per Code Embed, and a native Webflow form so sign-ups save under Forms.

Handoff page with copy buttons: https://r354306-cloud.github.io/sourceco-coinvest/webflow-handoff.html

Each block starts with a comment that says which page and block it is. Every block is under Webflow's 50,000 character limit for a Code Embed.

Tested in a stand-in Webflow page with deliberately clashing site styles: every element matched the original page on desktop and phone, and the form saved every field.

## Sponsor page

Preview: https://r354306-cloud.github.io/sourceco-coinvest/sponsors.html

- Suggested slug: `/lp/equity-connection-sponsors`
- SEO title: Equity Connection for Independent Sponsors and Search Funds | SourceCo
- Description: SourceCo Equity Connection: equity for independent sponsors and search funds through private equity firms, family offices and ultra-high-net-worth investors. Launching early 2027.
- Open Graph image: https://r354306-cloud.github.io/sourceco-coinvest/img/og-sponsors.jpg
- Form name: EC Sponsors - Founding List

### Steps

1. Create a new blank page with no site nav or footer. Suggested slug: `/lp/equity-connection-sponsors`. Set the SEO title, description and Open Graph image from the table above.
2. Add a Div Block and give it the ID `ec-page` in the Settings panel. Everything else goes inside it.
3. Add a Code Embed inside the div and paste block 01.
4. Add a second Code Embed under it and paste block 02.
5. Add a Form Block under that. Leave its default fields alone, the script clears them. Add a Code Embed inside the form and paste block 03. Optional: name the form `EC Sponsors - Founding List` so submissions are easy to find.
6. Add one last Code Embed under the Form Block and paste block 04.
7. Publish to webflow.io only. A small note in the bottom left corner says Setup check passed, or tells you what is off. Then fill in the form once and check the submission under Forms.

What the Navigator should look like when you are done:

```
Body
  Div Block  (ID: ec-page)
    Code Embed    01 Styles
    Code Embed    02 Page content
    Form Block
      Code Embed  03 Form fields
    Code Embed    04 Page script
```

### Blocks

- 01 Styles (28,997 characters): `sponsors/01-styles.txt`
- 02 Page content (22,172 characters): `sponsors/02-page-content.txt`
- 03 Form fields (3,011 characters): `sponsors/03-form-fields.txt`
- 04 Page script (25,159 characters): `sponsors/04-page-script.txt`

### Before you publish

- Three "Cheque size [$X to $X]" rows under "Who sees your deal" are left out until there are real ranges.
- The "[Founding terms to confirm]" note and the "[Founding sponsor terms to confirm]" note in the FAQ are left out.
- "If one closes with another buyer, you share in the fee." is still highlighted in gold. Confirm it or cut it before publishing.
- The footer lists `coinvest@sourcecodeals.com`. Check that inbox exists, or tell Ricky which address to use.
- Footer links point to `/lp/equity-connection-sponsors` and `/lp/equity-connection-investors`. If you use different slugs, tell Ricky and he will update the blocks.
- Images load from Ricky's preview site for now, so the page works as soon as you paste. When you have a minute, upload the files in the zip's img folder to Assets and swap the URLs.
- Decide whether the page should be indexed. The seller landing pages are a good guide.

### What each sign-up saves

Fields: `stage`, `sponsor_type`, `deals_closed`, `target_ebitda`, `sectors`, `wants`, `equity`, `first_name`, `last_name`, `firm`, `email`, `mobile`, `industries_focus`, `deal_details`, `heard_from`, plus the usual UTM and click ID fields, `lead_id`, `page_variant`, `lp_name` and `page_url`.

## Investor page

Preview: https://r354306-cloud.github.io/sourceco-coinvest/investors.html

- Suggested slug: `/lp/equity-connection-investors`
- SEO title: Equity Connection for Investors | SourceCo
- Description: Direct access to independent sponsor and search fund deals, vetted by SourceCo. For accredited investors and family offices. Launching Q1 2027.
- Open Graph image: https://r354306-cloud.github.io/sourceco-coinvest/img/og-investors.jpg
- Form name: EC Investors - Waitlist

### Steps

1. Create a new blank page with no site nav or footer. Suggested slug: `/lp/equity-connection-investors`. Set the SEO title, description and Open Graph image from the table above.
2. Add a Div Block and give it the ID `ec-page` in the Settings panel. Everything else goes inside it.
3. Add a Code Embed inside the div and paste block 01.
4. Add a second Code Embed under it and paste block 02.
5. Add a Form Block under that. Leave its default fields alone, the script clears them. Add a Code Embed inside the form and paste block 03. Optional: name the form `EC Investors - Waitlist` so submissions are easy to find.
6. Add one last Code Embed under the Form Block and paste block 04.
7. Publish to webflow.io only. A small note in the bottom left corner says Setup check passed, or tells you what is off. Then fill in the form once and check the submission under Forms.

What the Navigator should look like when you are done:

```
Body
  Div Block  (ID: ec-page)
    Code Embed    01 Styles
    Code Embed    02 Page content
    Form Block
      Code Embed  03 Form fields
    Code Embed    04 Page script
```

### Blocks

- 01 Styles (35,595 characters): `investors/01-styles.txt`
- 02 Page content (29,686 characters): `investors/02-page-content.txt`
- 03 Form fields (2,662 characters): `investors/03-form-fields.txt`
- 04 Page script (27,033 characters): `investors/04-page-script.txt`

### Before you publish

- The footer lists `coinvest@sourcecodeals.com`. Check that inbox exists, or tell Ricky which address to use.
- Footer links point to `/lp/equity-connection-sponsors` and `/lp/equity-connection-investors`. If you use different slugs, tell Ricky and he will update the blocks.
- Images load from Ricky's preview site for now, so the page works as soon as you paste. When you have a minute, upload the files in the zip's img folder to Assets and swap the URLs.
- Decide whether the page should be indexed. The seller landing pages are a good guide.

### What each sign-up saves

Fields: `accredited`, `check`, `interest`, `background`, `industries`, `first_name`, `last_name`, `email`, `mobile`, `heard_from`, `accredited_confirmed`, plus the usual UTM and click ID fields, `lead_id`, `page_variant`, `lp_name` and `page_url`.

## Editing copy later

- Headline options, form questions and the FAQ sit at the top of block 04, in `window.PAGE = {...}`.
- Section text is in block 02, with a comment above each section.

## Tracking

The page pushes three events to `dataLayer`: `coinvest_lead` when someone finishes the form, `ec_lead_saved` when Webflow confirms the save, and `ec_lead_error` if the save fails (the visitor sees a Try again link).
