# Equity Connection pages: Webflow paste kit

Tomos wrote these two pages himself and asked for them as real landing pages we can use. The copy is his, unchanged. This kit puts each page into Webflow the same way the HVAC, electrical and fleet pages went in: numbered blocks, one block per Code Embed, and a native Webflow form so sign-ups save under Forms.

Handoff page with copy buttons: https://r354306-cloud.github.io/sourceco-coinvest/webflow-handoff.html

Each block starts with a comment that says which page and block it is. Every block is under Webflow's 50,000 character limit for a Code Embed.

Tested in a stand-in Webflow page with deliberately clashing site styles: every element matched the original page on desktop and phone, and the form saved every field.

## Sponsor page

Preview: https://r354306-cloud.github.io/sourceco-coinvest/sponsors.html

- Suggested slug: `/lp/equity-connection-sponsors`
- SEO title: Equity Connection for Independent Sponsors and Search Funds | SourceCo
- Description: SourceCo Equity Connection: equity for independent sponsors and search funds through private equity firms, family offices and ultra-high-net-worth investors. Launching early 2027.
- Open Graph image: https://r354306-cloud.github.io/sourceco-coinvest/img/og-sponsors.jpg
- Form name: EC Sponsors - Founding List

### Steps

1. Create a new blank page with no site nav or footer. Suggested slug: `/lp/equity-connection-sponsors`. Set the SEO title, description and Open Graph image from the table above.
2. Add one Div Block to the page. In its settings give it the ID `ec-page`. Everything below goes inside this div.
3. Inside the div, add 5 Code Embeds one after another and paste blocks 01 to 05 in order, one block per embed.
4. Still inside the div, add a Form Block. In Form settings name it `EC Sponsors - Founding List`. Delete everything inside the form (labels, fields, button). Add one Code Embed inside the form and paste block 06. Leave the success and error messages as they are.
5. After the Form Block, still inside the div, add one more Code Embed and paste block 07.
6. Publish to the webflow.io staging domain only. Fill in the form once and check the submission shows up under Forms with every field filled. Then it is ready for Tomos to look at.

### Blocks

- 01 Styles (1 of 1) (28,789 characters): `sponsors/01-styles-1-of-1.txt`
- 02 Top bar and nav (900 characters): `sponsors/02-top-bar-and-nav.txt`
- 03 Sections: Hero, Two ways in, How it works, More than equity, Founding sponsors, Who sees your deal, Who leads it (15,969 characters): `sponsors/03-sections-hero-two-ways-in-how-it-works-m.txt`
- 04 Sections: Who it is for, Who built this, Questions, Final (3,535 characters): `sponsors/04-sections-who-it-is-for-who-built-this-qu.txt`
- 05 Footer and mobile button (1,746 characters): `sponsors/05-footer-and-mobile-button.txt`
- 06 Form fields (3,011 characters): `sponsors/06-form-fields.txt`
- 07 Page script (copy, FAQ, form logic, lead capture) (24,032 characters): `sponsors/07-page-script-copy-faq-form-logic-lead-cap.txt`

### Before you publish

- Three "Cheque size [$X to $X]" rows under "Who sees your deal" are left out until there are real ranges.
- The "[Founding terms to confirm]" note and the "[Founding sponsor terms to confirm]" note in the FAQ are left out.
- "If one closes with another buyer, you share in the fee." is still highlighted in gold. Confirm it or cut it before publishing.
- The footer lists `coinvest@sourcecodeals.com`. Check that inbox exists, or tell Ricky which address to use.
- Footer links point to `/lp/equity-connection-sponsors` and `/lp/equity-connection-investors`. If you use different slugs, tell Ricky and he will update the blocks.
- Images load from Ricky's preview site for now, so the page works as soon as you paste. When you have a minute, upload the files in the zip's img folder to Assets and swap the URLs.
- Decide whether the page should be indexed. The seller landing pages are a good guide.

### What each sign-up saves

Fields: `stage`, `sponsor_type`, `deals_closed`, `target_ebitda`, `sectors`, `wants`, `equity`, `first_name`, `last_name`, `firm`, `email`, `mobile`, `industries_focus`, `deal_details`, `heard_from`, plus the usual UTM and click ID fields, `lead_id`, `page_variant`, `lp_name` and `page_url`.

## Investor page

Preview: https://r354306-cloud.github.io/sourceco-coinvest/investors.html

- Suggested slug: `/lp/equity-connection-investors`
- SEO title: Equity Connection for Investors | SourceCo
- Description: Direct access to independent sponsor and search fund deals, vetted by SourceCo. For accredited investors and family offices. Launching Q1 2027.
- Open Graph image: https://r354306-cloud.github.io/sourceco-coinvest/img/og-investors.jpg
- Form name: EC Investors - Waitlist

### Steps

1. Create a new blank page with no site nav or footer. Suggested slug: `/lp/equity-connection-investors`. Set the SEO title, description and Open Graph image from the table above.
2. Add one Div Block to the page. In its settings give it the ID `ec-page`. Everything below goes inside this div.
3. Inside the div, add 5 Code Embeds one after another and paste blocks 01 to 05 in order, one block per embed.
4. Still inside the div, add a Form Block. In Form settings name it `EC Investors - Waitlist`. Delete everything inside the form (labels, fields, button). Add one Code Embed inside the form and paste block 06. Leave the success and error messages as they are.
5. After the Form Block, still inside the div, add one more Code Embed and paste block 07.
6. Publish to the webflow.io staging domain only. Fill in the form once and check the submission shows up under Forms with every field filled. Then it is ready for Tomos to look at.

### Blocks

- 01 Styles (1 of 1) (35,387 characters): `investors/01-styles-1-of-1.txt`
- 02 Top bar and nav (902 characters): `investors/02-top-bar-and-nav.txt`
- 03 Sections: Hero, Tint, Access, Why this part of the market, Fully vetted by sourceco, How it works (12,299 characters): `investors/03-sections-hero-tint-access-why-this-part-.txt`
- 04 Sections: What you would see, After close, Launching q1 2027, Who is behind it, What our clients say, Read this before you apply, Questions, Final (14,599 characters): `investors/04-sections-what-you-would-see-after-close-.txt`
- 05 Footer and mobile button (1,810 characters): `investors/05-footer-and-mobile-button.txt`
- 06 Form fields (2,662 characters): `investors/06-form-fields.txt`
- 07 Page script (copy, FAQ, form logic, lead capture) (25,906 characters): `investors/07-page-script-copy-faq-form-logic-lead-cap.txt`

### Before you publish

- The footer lists `coinvest@sourcecodeals.com`. Check that inbox exists, or tell Ricky which address to use.
- Footer links point to `/lp/equity-connection-sponsors` and `/lp/equity-connection-investors`. If you use different slugs, tell Ricky and he will update the blocks.
- Images load from Ricky's preview site for now, so the page works as soon as you paste. When you have a minute, upload the files in the zip's img folder to Assets and swap the URLs.
- Decide whether the page should be indexed. The seller landing pages are a good guide.

### What each sign-up saves

Fields: `accredited`, `check`, `interest`, `background`, `industries`, `first_name`, `last_name`, `email`, `mobile`, `heard_from`, `accredited_confirmed`, plus the usual UTM and click ID fields, `lead_id`, `page_variant`, `lp_name` and `page_url`.

## Editing copy later

- Headline options, form questions and the FAQ sit at the top of the last block, in `window.PAGE = {...}`.
- Section text is in the Sections blocks.

## Tracking

The page pushes three events to `dataLayer`: `coinvest_lead` when someone finishes the form, `ec_lead_saved` when Webflow confirms the save, and `ec_lead_error` if the save fails (the visitor sees a Try again link).
